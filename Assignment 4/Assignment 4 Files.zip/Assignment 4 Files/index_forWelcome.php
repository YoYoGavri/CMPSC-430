<html>
<body>

<form action = "welcome.php" method = "post">
Student ID: <input type = "text" name = "student_id"><br>
Student Name: <input type = "text" name = "student_name"><br>
Department Name: <input type = "text" name = "dept_name"><br>
Total Credits: <input type = "number" name = "total_creds"><br>
<input type = "submit">

</form>

</body>
</html>